﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class botones : MonoBehaviour
{
    private string urlBotones = "http://tadeolabhack.com:8081/test/Datos/habitosphp/PostSelect.php";


    //mio
    //private string urlBotones = "http://localhost/pruebas/PostSelect.php";

    private string IDitem = "";
    public string IdUser = "4";

    public void SelectIntem(string temp)
    {
        IDitem = temp;

        //es llamar a un metodo generando una pausa en la ejecución del programa hasta que se realiza lo que esta dentro del metodo
        StartCoroutine(sendItem());
    }

    private IEnumerator sendItem()
    {
        print(IDitem + "  " + IdUser);

        WWWForm form = new WWWForm();

        form.AddField("n", IdUser);
        form.AddField("uno", IDitem);

        WWW retroalimentacion = new WWW(urlBotones, form);

        yield return retroalimentacion;

        print(retroalimentacion.text);


    }








}
