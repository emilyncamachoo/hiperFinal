using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UserData : MonoBehaviour
{
    private string getUrlEscribir = "http://tadeolabhack.com:8081/test/Datos/habitosphp/escribir.php";


    //mio
    //private string getUrlEscribir = "http://localhost/pruebas/escribir.php";

    //public int IdUser = 1;
    private string nombre = "";
    private string sexo = "";
    private int edad = 0;
    private string res1 = "a";
    private string res2 = "a";
    private string res3 = "a";
    private string res4 = "a";
    private string res5 = "a";
    private string res6 = "a";
    private string res7 = "a";
    private string res8 = "a";
    private string res9 = "a";
    private string res10 = "a";

    //public Text prueba;



    public InputField campoNombre;
    public InputField campoSexo;
    public InputField campoEdad;

    //public InputField campoRespuestas;

    public void SenData()
    {
        //es llamar a un metodo generando una pausa en la ejecución del programa hasta que se realiza lo que esta dentro del metodo
        StartCoroutine(enviarDatosUsuario());
    }

    private IEnumerator enviarDatosUsuario()
    {
        nombre = campoNombre.text;
        sexo = campoSexo.text;
        //edad = campoEdad.text;

        if (campoEdad.text != "")
        {
            edad = int.Parse(campoEdad.text);
        }
        else
        {
            print("el campo de edad no puede estar vacio");
        }

        print(nombre + "  " + edad + " " + sexo + "  " + res1 + "  " + res2 + "  " + res3 + "  " + res4 + "  " + res5 + "  " + res6 + "  " + res7 + "  " + res8 + "  " + res9 + "  " + res10);


        if (nombre == "" || sexo == "" || edad == 0)
        {
            print("los campos de nombre, sexo y edad deben tener información");
        }
        else 
        {
            WWWForm form = new WWWForm();
            //form.AddField("identificacion", IdUser);
            form.AddField("nom", nombre);
            form.AddField("sexo", sexo);
            form.AddField("ed", edad);
            form.AddField("r1", res1);
            form.AddField("r2", res2);
            form.AddField("r3", res3);
            form.AddField("r4", res4);
            form.AddField("r5", res5);
            form.AddField("r6", res6);
            form.AddField("r7", res7);
            form.AddField("r8", res8);
            form.AddField("r9", res9);
            form.AddField("r10", res10);
            

            WWW retroalimentacion = new WWW(getUrlEscribir, form);
            yield return retroalimentacion;

            print(retroalimentacion.text);


        }

            

    }
}